# 0,1,···,n-1这n个数字排成一个圆圈，从数字0开始，每次从这个圆圈里删除第m个数字（删除后从下一个数字开始计数）。求出这个圆圈里剩下的最后一个数字。
#
# 例如，0、1、2、3、4这5个数字组成一个圆圈，从数字0开始每次删除第3个数字，则删除的前4个数字依次是2、0、4、1，因此最后剩下的数字是3。
#
#  
#
# 示例 1：
#
# 输入: n = 5, m = 3
# 输出: 3
# 示例 2：
#
# 输入: n = 10, m = 17
# 输出: 2
#  
#
# 限制：
#
# 1 <= n <= 10^5
# 1 <= m <= 10^6
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/yuan-quan-zhong-zui-hou-sheng-xia-de-shu-zi-lcof
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。


class Node:
    def __init__(self, val=0, next=None, pre=None):
        self.val = val
        self.next = next
        self.pre = pre


def print_node(head: Node):
    if head is None:
        return
    print(head.val)
    if head.next != head:
        print_node(head.next)


# 链表法
class Solution:
    def lastRemaining(self, n: int, m: int) -> int:
        head = Node(0, None)
        tmp = head
        for i in range(1, n):
            tmp.next = Node(i, None)
            tmp.next.pre = tmp
            tmp = tmp.next
        tail = tmp
        tail.next = head
        head.pre = tail

        while head != head.next:
            loop = 1
            target = head
            while loop < m:
                target = target.next
                loop += 1
            print("移除：", target.val)
            head = target.next
            target.pre.next = target.next
            target.next.pre = target.pre
        print_node(head)
        return head.val


# n = 5
# m = 2
# 倒推过程：
# ?
# x1 ? |x1| ?  说明位于第2个位置
# x1 ? |x2| x1 ? 说明位于第2个位置
# ? X2 |x3| x1 ? X2 说明位于第1个位置
# x3 x1 |x4| ? X2 x3 x1 说明位于第4个位置
# 此时倒推结束，？的值为3

# 数学法
class Solution2:
    def lastRemaining(self, n: int, m: int) -> int:
        weizhi = 0
        for i in range(2, n + 1):
            pre_weizhi = (weizhi + m) % i
            weizhi = pre_weizhi
        print(weizhi)
        return weizhi


res = Solution2().lastRemaining(5, 3)
print(res)
