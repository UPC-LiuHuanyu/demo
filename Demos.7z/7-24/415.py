# 字符串相加
# 给定两个字符串形式的非负整数
# num1
# 和num2 ，计算它们的和。
#
#
#
# 提示：
#
# num1
# 和num2
# 的长度都小于
# 5100
# num1
# 和num2
# 都只包含数字
# 0 - 9
# num1
# 和num2
# 都不包含任何前导零
# 你不能使用任何內建
# BigInteger
# 库， 也不能直接将输入的字符串转换为整数形式


class Solution:
    def addStrings(self, num1: str, num2: str) -> str:
        p1 = len(num1) - 1
        p2 = len(num2) - 1
        res = ""
        x = 0  # 十位
        y = 0  # 个位
        while p1 >= 0 or p2 >= 0:
            if p1 < 0:
                add1 = 0
            else:
                add1 = num1[p1]

            if p2 < 0:
                add2 = 0
            else:
                add2 = num2[p2]
            x, y = self.do_add(add1, add2, x)
            res = str(y) + res
            p1 -= 1
            p2 -= 1
        if x != 0:
            res = str(x) + res

        return res

    def do_add(self, n1: str, n2: str, plus: int):
        res = int(n1) + int(n2) + plus
        x = 1 if res >= 10 else 0
        # x = int(res / 10)
        y = res % 10
        return x, y


num1 = "1986132418960324165"
num2 = "874651986174103"
num1 = "1"
num2 = "9"
res = Solution().addStrings(num1, num2)
print(res)
print(len(res))
print(len(num1))
