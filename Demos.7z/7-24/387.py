# 给定一个字符串，找到它的第一个不重复的字符，并返回它的索引。如果不存在，则返回 -1。
#
#  
#
# 示例：
#
# s = "leetcode"
# 返回 0
#
# s = "loveleetcode"
# 返回 2
#  
#
# 提示：你可以假定该字符串只包含小写字母。
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/first-unique-character-in-a-string
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。

from collections import deque


# 暴力法
class Solution:
    def firstUniqChar(self, s: str) -> int:
        size = len(s)
        if size == 0:
            return -1
        elif size == 1:
            return 0

        first = []
        seen = set()
        for ele in s:
            if ele not in seen:
                if ele in first:
                    first.remove(ele)
                    seen.add(ele)
                else:
                    first.append(ele)
        if len(first) == 0:
            return -1
        return s.index(first[0])


# 暴力法的另一种实现
class Solution2:
    def firstUniqChar(self, s: str) -> int:
        size = len(s)
        if size == 0:
            return -1
        elif size == 1:
            return 0
        time_dic = {}
        seen = set()

        n = 0
        for i in range(size):
            ele = s[i]
            if ele not in seen:
                if ele in time_dic.keys():
                    del time_dic[ele]
                    seen.add(ele)
                else:
                    time_dic[ele] = (n, i)
                    n += 1
        print(time_dic)
        min_v = size
        mark = -1
        for k, (vn, vi) in time_dic.items():
            if min_v > vn:
                min_v = vn
                mark = vi

        return mark


s = "leetcode"
s = "loveleetcode"
res = Solution2().firstUniqChar(s)
print(res)
