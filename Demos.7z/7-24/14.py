# 编写一个函数来查找字符串数组中的最长公共前缀。
#
# 如果不存在公共前缀，返回空字符串 ""。
#
#  
#
# 示例 1：
#
# 输入：strs = ["flower","flow","flight"]
# 输出："fl"
# 示例 2：
#
# 输入：strs = ["dog","racecar","car"]
# 输出：""
# 解释：输入不存在公共前缀。
#  
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/longest-common-prefix
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
from typing import List


class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        size = len(strs)
        if size == 0:
            return ""
        common_pre = 0
        p = 0
        while p < len(strs[0]):
            common_flag = True
            for i in range(1, size):
                if p >= len(strs[i]) or strs[i][p] != strs[0][p]:
                    common_flag = False
                    break
            if common_flag:
                common_pre += 1
                p += 1
            else:
                break
        return strs[0][:common_pre]


strs = ["flower", "flow", "flight"]

res = Solution().longestCommonPrefix(strs)
print(res)
