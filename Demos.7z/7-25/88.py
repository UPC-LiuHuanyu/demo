# 给你两个有序整数数组
# nums1
# 和
# nums2，请你将
# nums2
# 合并到
# nums1
# 中，使
# nums1
# 成为一个有序数组。
#
# 初始化
# nums1
# 和
# nums2
# 的元素数量分别为
# m
# 和
# n 。你可以假设
# nums1
# 的空间大小等于
# m + n，这样它就有足够的空间保存来自
# nums2
# 的元素。
#
#
#
# 示例
# 1：
#
# 输入：nums1 = [1, 2, 3, 0, 0, 0], m = 3, nums2 = [2, 5, 6], n = 3
# 输出：[1, 2, 2, 3, 5, 6]
# 示例
# 2：
#
# 输入：nums1 = [1], m = 1, nums2 = [], n = 0
# 输出：[1]
#
# 提示：
#
# nums1.length == m + n
# nums2.length == n
# 0 <= m, n <= 200
# 1 <= m + n <= 200
# -109 <= nums1[i], nums2[i] <= 109
from typing import List

from collections import deque


class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
        """
        Do not return anything, modify nums1 in-place instead.
        """

        nums3 = []

        p1 = 0
        p2 = 0

        while p1 < m and p2 < n:
            if nums1[p1] < nums2[p2]:
                nums3.append(nums1[p1])
                p1 += 1
            else:
                nums3.append(nums2[p2])
                p2 += 1

        if p1 < m:
            nums3 += nums1[p1:]
        else:
            nums3 += nums2[p2:]
        i = 0
        while i < m + n:
            nums1[i] = nums3[i]
            i += 1


n1 = [1, 2, 3, 4, 5, 6, 8, 78, 0, 0, 0, 0, 0, 0]
n2 = [4, 15, 26, 28, 38, ]

Solution().merge(n1, 8, n2, 5)

print(n1)
