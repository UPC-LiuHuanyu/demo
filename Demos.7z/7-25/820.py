# 单词数组 words 的 有效编码 由任意助记字符串 s 和下标数组 indices 组成，且满足：
#
# words.length == indices.length
# 助记字符串 s 以 '#' 字符结尾
# 对于每个下标 indices[i] ，s 的一个从 indices[i] 开始、到下一个 '#' 字符结束（但不包括 '#'）的 子字符串 恰好与 words[i] 相等
# 给你一个单词数组 words ，返回成功对 words 进行编码的最小助记字符串 s 的长度 。
#
#  
#
# 示例 1：
#
# 输入：words = ["time", "me", "bell"]
# 输出：10
# 解释：一组有效编码为 s = "time#bell#" 和 indices = [0, 2, 5] 。
# words[0] = "time" ，s 开始于 indices[0] = 0 到下一个 '#' 结束的子字符串，如加粗部分所示 "time#bell#"
# words[1] = "me" ，s 开始于 indices[1] = 2 到下一个 '#' 结束的子字符串，如加粗部分所示 "time#bell#"
# words[2] = "bell" ，s 开始于 indices[2] = 5 到下一个 '#' 结束的子字符串，如加粗部分所示 "time#bell#"
# 示例 2：
#
# 输入：words = ["t"]
# 输出：2
# 解释：一组有效编码为 s = "t#" 和 indices = [0] 。
#  
#
# 提示：
#
# 1 <= words.length <= 2000
# 1 <= words[i].length <= 7
# words[i] 仅由小写字母组成
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/short-encoding-of-words
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
from typing import List


class Solution:
    def minimumLengthEncoding(self, words: List[str]) -> int:
        # delta = self.include(words[0], words[1])
        # print(delta)
        keys = []
        values = [-1 for _ in range(len(words))]
        for wordId in range(len(words)):
            word = words[wordId]
            done = False
            for i in range(len(keys)):
                key = keys[i]
                res = self.include(word, key)
                if res == 0:
                    continue
                elif res > 0:
                    values[wordId] = (i, res)
                else:
                    keys[i] = word
                    values[wordId] = (i, -res)
                done = True
                break
            if not done:
                keys.append(word)
                values[wordId] = (len(keys) - 1, len(word) - 1)
        print(keys)
        print(values)
        res = 0
        s = ""
        for key in keys:
            res += len(key) + 1
            s += key + "#"
        print(s)
        print(res)
        return res

    # 返回负数代表word包含key，正数代表key包含word，0代表互不包含
    def include(self, word, key) -> int:
        res = len(word) - 1
        p1 = len(word) - 1
        p2 = len(key) - 1
        while p1 >= 0 and p2 >= 0 and word[p1] == key[p2]:
            p1 -= 1
            p2 -= 1
        if p1 > -1 and p2 > -1:
            return 0
        # 说明k2比较长
        if p1 == -1:
            return res
        else:
            return -res


class Solution2:
    def minimumLengthEncoding(self, words: List[str]) -> int:
        keys = []
        res_len = 0
        for wordId in range(len(words)):
            word = words[wordId]
            done = False
            for i in range(len(keys)):
                key = keys[i]
                res = self.include(word, key)
                if res is None:
                    continue
                elif res < 0:
                    keys[i] = word
                    res_len = res_len - len(key) + len(word)
                done = True
                break
            if not done:
                keys.append(word)
                res_len += len(word)
        return res_len

    # 返回负数代表word包含key，正数代表key包含word，0代表互不包含
    def include(self, word, key) -> int:
        res = len(word) - 1
        p1 = len(word) - 1
        p2 = len(key) - 1
        while p1 >= 0 and p2 >= 0 and word[p1] == key[p2]:
            p1 -= 1
            p2 -= 1
        if p1 > -1 and p2 > -1:
            return None
        # 说明k2比较长
        if p1 == -1:
            return res
        else:
            return -res


# 抛弃子字符串组成的set元素
class Solution3:
    def minimumLengthEncoding(self, words: List[str]) -> int:

        cache = set(words)

        for word in words:
            for i in range(1, len(word)):
                cache.discard(word[i:])
        res = 0
        for word in cache:
            res += len(word) + 1
        return res


import collections


# 字典树

class Node:
    def __init__(self, val: str):
        self.children = {}

# 太麻烦不看了, 考场上临时去学吧, 大概意思就是根节点的children存了倒数第一个的若干字母, 倒着用树的形式来判断这个单词是否已经在树上, 不在的话就需要创建新的节点
# 每个叶节点都是一个新的单词, 最后把所有叶节点所对应的单词加入到set中, 返回set中所有元素的长度之和即可
class Solution4:
    def minimumLengthEncoding(self, words: List[str]) -> int:
        pass

words = ["time", "me", "bell"]
Solution().minimumLengthEncoding(words)
