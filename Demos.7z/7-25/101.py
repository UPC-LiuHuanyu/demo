# 给定一个二叉树，检查它是否是镜像对称的。
#
#
#
# 例如，二叉树[1, 2, 2, 3, 4, 4, 3]
# 是对称的。
#
# 但是下面这个[1, 2, 2, null, 3, null, 3]
# 则不是镜像对称的:
#
#
# 进阶：
#
# 你可以运用递归和迭代两种方法解决这个问题吗？

# Definition for a binary tree node.
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

    def __str__(self):
        return self.val


class Solution:
    def isSymmetric(self, root: TreeNode) -> bool:
        this_l = [root]

        next_l = []
        while len(this_l) > 0:
            print("this_l")
            self.print(this_l)
            if not self.is_arr_symmetic(this_l):
                return False
            for ele in this_l:
                if ele is not None:
                    next_l.append(ele.left)
                    next_l.append(ele.right)
            print("next_l")
            self.print(next_l)
            this_l = next_l
            next_l = []
        return True

    def is_arr_symmetic(self, arr):
        p0 = 0
        p1 = len(arr) - 1
        while p0 < p1:
            if arr[p0] is None or arr[p1] is None:
                if arr[p0] != arr[p1]:
                    return False
            elif arr[p0].val != arr[p1].val:
                return False
            p0 += 1
            p1 -= 1
        return True

    def print(self, list):
        print("------")
        for ele in list:
            if ele is None:
                print("None")
            else:
                print(ele.val)


n1 = TreeNode(1)
n1.left = TreeNode(2)
n1.right = TreeNode(2)
n1.left.left = TreeNode(3)
n1.left.right = TreeNode(4)

n1.right.left = TreeNode(4)
n1.right.right = TreeNode(3)

res = Solution().isSymmetric(n1)
print(res)
