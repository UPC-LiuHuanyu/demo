# 给定一个整数数组 nums ，找到一个具有最大和的连续子数组（子数组最少包含一个元素），返回其最大和。
#
#  
#
# 示例 1：
#
# 输入：nums = [-2,1,-3,4,-1,2,1,-5,4]
# 输出：6
# 解释：连续子数组 [4,-1,2,1] 的和最大，为 6 。
# 示例 2：
#
# 输入：nums = [1]
# 输出：1
# 示例 3：
#
# 输入：nums = [0]
# 输出：0
# 示例 4：
#
# 输入：nums = [-1]
# 输出：-1
# 示例 5：
#
# 输入：nums = [-100000]
# 输出：-100000
#  
#
# 提示：
#
# 1 <= nums.length <= 3 * 104
# -105 <= nums[i] <= 105
#  
#
# 进阶：如果你已经实现复杂度为 O(n) 的解法，尝试使用更为精妙的 分治法 求解。
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/maximum-subarray
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
from typing import List


# 暴力法 O(n**3)
class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        self.size = len(nums)
        self.nums = nums
        maxi = 0
        debug_i = 0
        debug_j = 0
        for i in range(self.size):
            for j in range(i, self.size):
                tmp = sum(self.nums[i:j + 1])
                if maxi is None or tmp > maxi:
                    maxi = tmp
                    debug_i = i
                    debug_j = j
        print(debug_i)
        print(debug_j + 1)
        return maxi


# 动态规划O(n**2)
class Solution2:
    def maxSubArray(self, nums: List[int]) -> int:
        self.size = len(nums)
        self.nums = nums
        maxi = nums[0]
        debug_i = 0
        debug_j = 0
        dp = [[0 for _ in range(self.size)] for _ in range(self.size)]
        for i in range(self.size - 1, -1, -1):
            for j in range(i, self.size):
                if j - i == 0:
                    dp[i][j] = self.nums[i]
                else:
                    dp[i][j] = dp[i][j - 1] + self.nums[j]
                if dp[i][j] > maxi:
                    maxi = dp[i][j]
                    debug_i = i
                    debug_j = j
        print(debug_i)
        print(debug_j)
        return maxi


# 动态规划2O(n)
class Solution3:
    def maxSubArray(self, nums: List[int]) -> int:
        self.size = len(nums)
        if self.size < 1:
            return None
        maxsum = nums[0]
        tmpsum = nums[0]
        for i in range(1, self.size):
            if tmpsum < 0:
                tmpsum = nums[i]
            else:
                tmpsum += nums[i]
            if tmpsum > maxsum:
                maxsum = tmpsum
        return maxsum


# 线段树
class Solution4:
    def maxSubArray(self, nums: List[int]) -> int:
        self.nums = nums
        # lsum：左起最大子序列
        # rsum：右起最大子序列
        # isum: 总和
        # bigsum: ：实际最大子序列
        (lsum, rsum, isum, bigsum) = self.divid_conqure(0, len(nums) - 1)
        print(lsum, rsum, isum, bigsum)
        return bigsum

    def divid_conqure(self, i, j):
        if j - i == 0:
            lsum = self.nums[i]
            rsum = self.nums[i]
            isum = self.nums[i]
            bigsum = self.nums[i]
            return (lsum, rsum, isum, bigsum)
        else:
            m = int((i + j) / 2)
            (lsum1, rsum1, isum1, bigsum1) = self.divid_conqure(i, m)
            (lsum2, rsum2, isum2, bigsum2) = self.divid_conqure(m + 1, j)
            isum = isum1 + isum2
            lsum = max(lsum1, isum1 + lsum2)
            rsum = max(rsum2, isum2 + rsum1)
            bigsum = max(bigsum1, bigsum2, rsum1 + lsum2)
            return (lsum, rsum, isum, bigsum)


nums = [1]
nums = [5, 4, -1, 7, 8]
nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
nums = [-1, -2]
nums = [-1, 0, -2]
nums =[-2,-2,-3,0,-3,1,-3]

res = Solution4().maxSubArray(nums)
print(res)

# nums = [1, 1, 1, 1, 1, 1]
# print(sum(nums[0:6]))
