# 给定两个字符串 s1 和 s2，写一个函数来判断 s2 是否包含 s1 的排列。
#
# 换句话说，第一个字符串的排列之一是第二个字符串的 子串 。
#
#  
#
# 示例 1：
#
# 输入: s1 = "ab" s2 = "eidbaooo"
# 输出: True
# 解释: s2 包含 s1 的排列之一 ("ba").
# 示例 2：
#
# 输入: s1= "ab" s2 = "eidboaoo"
# 输出: False
#  
#
# 提示：
#
# 1 <= s1.length, s2.length <= 104
# s1 和 s2 仅包含小写字母
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/permutation-in-string
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。

from typing import Dict

class Solution:
    def checkInclusion(self, s1: str, s2: str) -> bool:
        size = len(s1)
        max_len = len(s2)
        if size > max_len:
            return False
        lp = 0
        rp = lp + size

        dic1 = self.map_str(s1)
        tmp_dic = self.map_str(s2[lp:rp])
        if self.is_ok(dic1, tmp_dic):
            return True
        while rp < max_len:
            tmp_dic[s2[lp]] -= 1
            if tmp_dic[s2[lp]] == 0:
                del tmp_dic[s2[lp]]
            if s2[rp] in tmp_dic.keys():
                tmp_dic[s2[rp]] += 1
            else:
                tmp_dic[s2[rp]] = 1
            lp += 1
            rp += 1
            if self.is_ok(dic1, tmp_dic):
                return True
        return False

    def map_str(self, string) -> Dict[str, int]:
        res = {}
        for i in range(len(string)):
            tmp_key = string[i]
            if tmp_key in res.keys():
                res[tmp_key] += 1
            else:
                res[tmp_key] = 1
        return res

    def is_ok(self, map1: Dict[str, int], map2: Dict[str, int]):
        if len(map1.keys()) != len(map2.keys()):
            return False
        for k, v in map1.items():
            if k not in map2.keys():
                return False
            elif map2[k] != v:
                return False
        return True



class Solution2:
    def checkInclusion(self, s1: str, s2: str) -> bool:
        size = len(s1)
        max_len = len(s2)
        if size > max_len:
            return False
        lp = 0
        rp = lp + size

        dic1 = self.map_str(s1)
        tmp_dic = self.map_str(s2[lp:rp])
        if self.is_ok(dic1, tmp_dic):
            return True
        while rp < max_len:
            tmp_dic[s2[lp]] -= 1
            if s2[rp] in tmp_dic.keys():
                tmp_dic[s2[rp]] += 1
            else:
                tmp_dic[s2[rp]] = 1
            lp += 1
            rp += 1
            if self.is_ok(dic1, tmp_dic):
                return True
        return False

    def map_str(self, string) -> Dict[str, int]:
        res = {}
        for i in range(len(string)):
            tmp_key = string[i]
            if tmp_key in res.keys():
                res[tmp_key] += 1
            else:
                res[tmp_key] = 1
        return res

    def is_ok(self, map1: Dict[str, int], map2: Dict[str, int]):
        for k, v in map1.items():
            if k not in map2.keys():
                return False
            elif map2[k] != v:
                return False
        return True

s1 = "ab"
s2 = "eidbaooo"

s1 ="ab"
s2 ="eidboaoo"
# s1 = "ab"
# s2 = "eidboaoo"
#
# s1 ="a"
# s2 ="ab"
res = Solution().checkInclusion(s1, s2)
print(res)
