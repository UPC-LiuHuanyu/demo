# 给定一个包含了一些 0 和 1 的非空二维数组 grid 。
#
# 一个 岛屿 是由一些相邻的 1 (代表土地) 构成的组合，这里的「相邻」要求两个 1 必须在水平或者竖直方向上相邻。你可以假设 grid 的四个边缘都被 0（代表水）包围着。
#
# 找到给定的二维数组中最大的岛屿面积。(如果没有岛屿，则返回面积为 0 。)
#
#  
#
# 示例 1:
#
# [[0,0,1,0,0,0,0,1,0,0,0,0,0],
#  [0,0,0,0,0,0,0,1,1,1,0,0,0],
#  [0,1,1,0,1,0,0,0,0,0,0,0,0],
#  [0,1,0,0,1,1,0,0,1,0,1,0,0],
#  [0,1,0,0,1,1,0,0,1,1,1,0,0],
#  [0,0,0,0,0,0,0,0,0,0,1,0,0],
#  [0,0,0,0,0,0,0,1,1,1,0,0,0],
#  [0,0,0,0,0,0,0,1,1,0,0,0,0]]
# 对于上面这个给定矩阵应返回 6。注意答案不应该是 11 ，因为岛屿只能包含水平或垂直的四个方向的 1 。
#
# 示例 2:
#
# [[0,0,0,0,0,0,0,0]]
# 对于上面这个给定的矩阵, 返回 0。
#
#  
#
# 注意: 给定的矩阵grid 的长度和宽度都不超过 50。
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/max-area-of-island
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。

# 思路：这个问题和Add转AddN的pass很像，找到一组一组的邻接点即可
from typing import List

from collections import deque


class Solution:
    def maxAreaOfIsland(self, grid: List[List[int]]) -> int:
        self.height = len(grid)
        if self.height == 0:
            return 0
        self.width = len(grid[0])
        self.grid = grid
        max_s = 0
        self.explored = [[False for i in range(self.width)] for j in range(self.height)]
        print(self.explored)
        for i in range(self.height):
            for j in range(self.width):
                if self.explored[i][j]:
                    continue
                self.explored[i][j] = True
                if self.grid[i][j] == 0:
                    continue
                # 未探索过（explored = False）的土地（grid = 1），则需要探索
                island = []
                island.append((i, j))
                # explore bfs-ly
                open_list = deque()
                open_list.append((i, j))
                while len(open_list) > 0:
                    now = open_list.popleft()
                    neighbors = self.get_neighbors(now)
                    for neighbor in neighbors:
                        x = neighbor[0]
                        y = neighbor[1]
                        if self.explored[x][y]:
                            continue
                        self.explored[x][y] = True
                        open_list.append(neighbor)
                        island.append(neighbor)
                print(island)
                tmp_s = len(island)
                max_s = max(max_s, tmp_s)
                print(tmp_s)
        return max_s

    def get_neighbors(self, point: (int, int)) -> List:
        res = [
            (point[0] + 1, point[1]),
            (point[0] - 1, point[1]),
            (point[0], point[1] - 1),
            (point[0], point[1] + 1)]
        i = 0
        while i < len(res):
            x = res[i][0]
            y = res[i][1]
            if (x < 0 or x >= self.height) or (y < 0 or y >= self.width) or self.grid[x][y] == 0:
                res.remove(res[i])
                i -= 1
            i += 1
        return res

grid = \
    [[0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
     [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0],
     [0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
     [0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0],
     [0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0],
     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
     [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0],
     [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0]]

print(len(grid) * len(grid[0]))
res = Solution().maxAreaOfIsland(grid)
print(res)
