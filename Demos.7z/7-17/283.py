# 给定一个数组 nums，编写一个函数将所有 0 移动到数组的末尾，同时保持非零元素的相对顺序。
#
# 示例:
#
# 输入: [0,1,0,3,12]
# 输出: [1,3,12,0,0]

# flag
# [0,1,0,3,12]
# [1,0,3,12]

# [1,0,3,12,0]
# [1,0,3,12,0]

# 说明:
#
# 必须在原数组上操作，不能拷贝额外的数组。
# 尽量减少操作次数。
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/move-zeroes
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
from typing import List


class Solution1(object):
    def moveZeroes(self, nums: List[int]):
        """
        :type nums: List[int]
        :rtype: None Do not return anything, modify nums in-place instead.
        """

        flag = 0
        i = 0
        while i < len(nums):
            if nums[i] == 0:
                nums.remove(0)
                i -= 1
                flag += 1
            i += 1
        nums += [0] * flag


class Solution2(object):
    def moveZeroes(self, nums: List[int]):
        """
        :type nums: List[int]
        :rtype: None Do not return anything, modify nums in-place instead.
        """

        size = len(nums)
        for i in range(size):
            for j in range(i, size):
                if self.should_change(nums[i], nums[j]):
                    tmp = nums[i]
                    nums[i] = nums[j]
                    nums[j] = tmp

    def should_change(self, a, b):
        if a == 0:
            return True
        else:
            return False


class Solution3(object):
    def moveZeroes(self, nums: List[int]):
        """
        :type nums: List[int]
        :rtype: None Do not return anything, modify nums in-place instead.
        """

        size = len(nums)
        l_p = 0
        r_p = 1
        while r_p < size:
            if nums[l_p] != 0:
                l_p += 1
                r_p += 1
            else:
                if nums[r_p] != 0:
                    tmp = nums[r_p]
                    nums[r_p] = nums[l_p]
                    nums[l_p] = tmp
                    l_p += 1
                    r_p += 1
                else:
                    r_p += 1



nums = [0, 1, 0, 3, 2, 4, 6, 7, 0, 9, 1, 0, 3]
print(nums)

Solution3().moveZeroes(nums)

print(nums)
