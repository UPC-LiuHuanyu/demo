# 给定一个字符串，你需要反转字符串中每个单词的字符顺序，同时仍保留空格和单词的初始顺序。
#
#  
#
# 示例：
#
# 输入："Let's take LeetCode contest"
# 输出："s'teL ekat edoCteeL tsetnoc"
#  
#
# 提示：
#
# 在字符串中，每个单词由单个空格分隔，并且字符串中不会有任何额外的空格。
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/reverse-words-in-a-string-iii
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
from typing import List


class Solution:
    def reverseWords(self, s: str) -> str:

        words = s.split(" ")

        res = []
        for word in words:
            print(word)
            arr = list(word)
            print(arr)
            res += self.reverse(arr)
            res.append(" ")

        res_str = "".join(res[:-1])
        return res_str

    def reverse(self, word: List[str]):
        size = len(word)
        lp = 0
        rp = size - 1
        while lp < rp:
            tmp = word[lp]
            word[lp] = word[rp]
            word[rp] = tmp
            lp += 1
            rp -= 1
        return word
print(list("asdasdas"))
res = Solution().reverseWords("Let's take LeetCode contest")
print(res)
