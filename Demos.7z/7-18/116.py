# 给定一个 完美二叉树 ，其所有叶子节点都在同一层，每个父节点都有两个子节点。二叉树定义如下：
#
# struct 'Node' {
#   int val;
#   'Node' *left;
#   'Node' *right;
#   'Node' *next;
# }
# 填充它的每个 next 指针，让这个指针指向其下一个右侧节点。如果找不到下一个右侧节点，则将 next 指针设置为 NULL。
#
# 初始状态下，所有 next 指针都被设置为 NULL。
#
#  
#
# 进阶：
#
# 你只能使用常量级额外空间。
# 使用递归解题也符合要求，本题中递归程序占用的栈空间不算做额外的空间复杂度。
#  
#
# 示例：
#
# https://assets.leetcode.com/uploads/2019/02/14/116_sample.png
#
# 输入：root = [1,2,3,4,5,6,7]
# 输出：[1,#,2,3,#,4,5,6,7,#]
# 解释：给定二叉树如图 A 所示，你的函数应该填充它的每个 next 指针，以指向其下一个右侧节点，如图 B 所示。序列化的输出按层序遍历排列，同一层节点由 next 指针连接，'#' 标志着每一层的结束。
#
# 来源：力扣（LeetCode）
# 链接：https://leetcode-cn.com/problems/populating-next-right-pointers-in-each-node
# 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
from typing import Deque


class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next

    def __str__(self):
        return "<val = {}, next = {}>".format(self.val, self.next)


def ite_tree(root: Node):
    print(root.val)
    print("{} next is {}".format(root.val, root.next))
    if root.left is not None:
        ite_tree(root.left)
    if root.right is not None:
        ite_tree(root.right)


# 利用父子节点之间的连接关系，为下一层的right建立next连接
class Solution:
    def connect(self, root: 'Node') -> 'Node':
        if root is None:
            return None
        self.connect_with_parent(root)
        return root

    def connect_with_parent(self, this_node: 'Node'):
        if this_node.left is None and this_node.right is None:
            return
        this_node.left.next = this_node.right
        if this_node.next is not None:
            this_node.right.next = this_node.next.left
        else:
            this_node.right.next = None
        self.connect_with_parent(this_node.left)
        self.connect_with_parent(this_node.right)


from collections import deque


class Solution2:
    def connect(self, root: 'Node') -> 'Node':
        if root is None:
            return None
        q1 = deque()
        q1.append(root)
        while len(q1) > 0:
            q2 = deque()
            # 根据本层，把本层的子节点加入到下一层
            while len(q1) > 0:
                ele = q1.popleft()
                if ele.left is not None:
                    q2.append(ele.left)
                if ele.right is not None:
                    q2.append(ele.right)
            # 得到下一层的节点后，建立连接
            q2_bak = deque(q2)
            while len(q2_bak) > 1:
                tmp = q2_bak.popleft()
                tmp.next = q2_bak[0]
            # 继续下一层
            q1 = q2
        return root


class Solution3:
    def connect(self, root: 'Node') -> 'Node':
        if root is None:
            return None
        q1 = deque()
        q1.append(root)
        while len(q1) > 0:
            q2 = deque()
            # 根据本层，把本层的子节点加入到下一层
            while len(q1) > 0:
                ele = q1.popleft()
                self.do_append(ele.left, q2)
                self.do_append(ele.right, q2)
            q1 = q2
        return root

    def do_append(self, ele: 'Node', q: Deque):
        if ele is None:
            return
        else:
            if len(q) > 0:
                q[-1].next = ele
            q.append(ele)


root = Node(1, Node(), Node())
root.left = Node(2, Node(), Node())
root.right = Node(3, Node(), Node())
root.left.left = Node(4, None, None)
root.left.right = Node(5, None, None)
root.right.left = Node(6, None, None)
root.right.right = Node(7, None, None)
ite_tree(root)
Solution3().connect(root)
print("-------------------")
ite_tree(root)
